$('.btn_menu').click(function() {
	if ($(".menu_box").height() == 0) {
		var _h = 600;
		$(".menu_box").height(_h);
		$(this).removeClass('menu_close').addClass('menu_open');

	} else {
		$(".menu_box").height(0);
		$(this).removeClass('menu_open').addClass('menu_close');
	}

});

$('.btn_lg').click(function() {
	if ($(".language_box").height() == 0) {
		var _h = $('.language_list').get(0).offsetHeight;
		$(".language_box").height(_h);
		$(this).addClass('language_open');

	} else {
		$(".language_box").height(0);
		$(this).removeClass('language_open');
	}

});

function tplToHTML(data, domID, tplID){
	var tpl = $(tplID).html();
	var html = juicer(tpl.replace(/[\r\n\t]/g,'').replace(/(^\s*)|(\s*$)/g,''), data);
	html = html.replace(/{%/g,'<em class="im">').replace(/%}/g,'</em>');
	$(domID).html(html );

}
function getQueryVariable(variable)
{
	   var query = window.location.search.substring(1);
	   var vars = query.split("&");
	   for (var i=0;i<vars.length;i++) {
			   var pair = vars[i].split("=");
			   if(pair[0] == variable){return pair[1];}
	   }
	   return(false);
}


function resizePage() {
	var screenWidth = $(window).width();
	console.log(screenWidth)
	console.log( screenWidth / 1920)
	if (screenWidth < 1920) {
		$('body').css({
			zoom: screenWidth / 1920
		});
	}
}

function setHTML(callback){
	var lang = getQueryVariable('lang');
	$('.wrap').addClass(lang);
	$.get('/api/ss_ea/init?type=1&lang=' + lang, function(data) {
		$.getJSON("lang.json",function(langJson){
		
		
			// var lang =  getQueryVariable('lang');
			langData = langJson[lang];
			data.data.lang = langData;
			tplToHTML(data.data, '#menuList', '#menuTpl');
			callback(data);
			
			// for(var key in langData){
			// 	if(key!='menu' && key!='subMenu'){
			// 		var el = $('#'+key);
			// 		if(el.size()>0){
			// 			$('#'+key).text(langData[key]);
			// 		}else{
			// 			$('.'+key).text(langData[key]);
			// 		}
			// 	}else if(key=='menu'){
			// 		//menu
			// 		tplToHTML(langData, '#menuList', '#menuTpl');
			// 	}
				
				
				
				
			// }
			
			
			
		   // console.log("数据: " + data + "\n状态: " + status);
		});
	  
	  
	});
}


$(function(){
	$(window).resize(resizePage);
	resizePage();
	
	
	var dateFormat = function(str){
	   //var str = '"'+ss+'"';
	   var date = str.split(' ')[0].split('-');
	   return date.reverse().join('/');
	  }
	  juicer.register('dateFormat', dateFormat); //注册自定义函数
	  
	  var strToUpperCase = function(str){
	   
	   return str.toUpperCase();
	  }
	  juicer.register('strToUpperCase', strToUpperCase); //注册自定义函数
	  
	  var lang = getQueryVariable('lang');
	  switch(lang){
	  	case 'EN':
	  		var langName = 'English';
	  		break;
	  	case 'FR':
	  		var langName = 'Français';
	  		break;
	  	case 'DE':
	  		var langName = 'Deutsch';
	  		break;
	  	case 'RU':
	  		var langName = 'Русский';
	  		break;
	  	case 'AR':
	  		var langName = 'العربية';
	  		break;
	  	
	  }
	  $('.btn_lg').text(langName);
	  
	
	
	  
	  
	//  $.get('http://34.217.206.52:8090/api/ss_ea/getLangList',function(lang){
	// 	// lang = {"errCode":0,"errMsg":"OK","data":["EN"]};
	// 	tplToHTML({'lang':lang.data}, '#languageHTML', '#languageTpl');
	// });
	
	
});
