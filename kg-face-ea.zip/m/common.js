let u = navigator.userAgent;
let isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1; //g
let isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
if (isAndroid) {
    //这个是安卓操作系统
    console.log("这个是安卓")
	$('.btn_download').click(function(){
		window.open(pageData.data.downloads.android);
	});
}
if (isIOS) {
    //这个是ios操作系统
    console.log("这个是ios");
	$('.btn_download').click(function(){
		window.open(pageData.data.downloads.ios);
	});
}
$('.btn_menu').click(function () {
	if ($(".menu_box").height() == 0) {
		var _h = 1260;
		$(".menu_box").height(_h);
		$(this).removeClass('menu_close').addClass('menu_open');

	} else {
		$(".menu_box").height(0);
		$(this).removeClass('menu_open').addClass('menu_close');
	}

});

$('.btn_lg').click(function() {
	if ($(".language_box").height() == 0) {
		var _h = $('.language_list').get(0).offsetHeight;
		$(".language_box").height(_h);
		$(this).addClass('language_open');

	} else {
		$(".language_box").height(0);
		$(this).removeClass('language_open');
	}

});

$(".btn_download").click(function () { 
    
});

function tplToHTML(data, domID, tplID){
	var tpl = $(tplID).html();
	var html = juicer(tpl.replace(/[\r\n\t]/g,'').replace(/(^\s*)|(\s*$)/g,''), data);
	html = html.replace(/{%/g,'<em class="im">').replace(/%}/g,'</em>');
	$(domID).html(html );

}
function getQueryVariable(variable)
{
	   var query = window.location.search.substring(1);
	   var vars = query.split("&");
	   for (var i=0;i<vars.length;i++) {
			   var pair = vars[i].split("=");
			   if(pair[0] == variable){return pair[1];}
	   }
	   return(false);
}


function resizePage() {
	var screenWidth = $(window).width();
	console.log(screenWidth)
	console.log( screenWidth / 1080)
	if (screenWidth < 1080) {
		$('body').css({
			zoom: screenWidth / 1080
		});
		$('.wrap').show();
	}
}

function setHTML(callback){
	var lang = getQueryVariable('lang');
	$('.wrap').addClass(lang);
	$.get('/api/ss_ea/init?type=2&lang=' + lang, function(data) {
		$.getJSON("../lang.json",function(langJson){
		
		
			// var lang =  getQueryVariable('lang');
			langData = langJson[lang];
			data.data.lang = langData;
			tplToHTML(data.data, '#menuList', '#menuTpl');
			callback(data);
			
			// for(var key in langData){
			// 	if(key!='menu' && key!='subMenu'){
			// 		var el = $('#'+key);
			// 		if(el.size()>0){
			// 			$('#'+key).text(langData[key]);
			// 		}else{
			// 			$('.'+key).text(langData[key]);
			// 		}
			// 	}else if(key=='menu'){
			// 		//menu
			// 		tplToHTML(langData, '#menuList', '#menuTpl');
			// 	}
				
				
				
				
			// }
			
			
			
		   // console.log("数据: " + data + "\n状态: " + status);
		});
	  
	  
	});
}

$(function(){
	$(window).resize(resizePage);
	resizePage();
	
	var dateFormat = function(str){
	   //var str = '"'+ss+'"';
	   
	   var date = str.split(' ')[0].split('-');
	   return date.reverse().join('/');
	}
	juicer.register('dateFormat', dateFormat); //注册自定义函数
	
	 var strToUpperCase = function(str){
	   
	   return str.toUpperCase();
	  }
	  juicer.register('strToUpperCase', strToUpperCase); //注册自定义函数
	  
	  
	  
	
	  
	  
	  /*
	  $.getJSON("../lang.json",function(data){


			// var lang =  getQueryVariable('lang');
			langData = data[lang];
			for(var key in langData){
				if(key!='menu' && key!='subMenu'){
					var el = $('#'+key);
					if(el.size()>0){
						$('#'+key).text(langData[key]);
					}else{
						$('.'+key).text(langData[key]);
					}
				}else if(key=='menu'){
					//menu
					tplToHTML(langData, '#menuList', '#menuTpl');
				}
				
				
				
				
			}
			
			
			
		   // console.log("数据: " + data + "\n状态: " + status);
		});
	*/
	
	// $.get('http://34.217.206.52:8090/api/ss_ea/getLangList',function(lang){
	// 	// lang = {"errCode":0,"errMsg":"OK","data":["EN"]};
	// 	tplToHTML({'lang':lang.data}, '#languageHTML', '#languageTpl');
	// });
	
	
});
