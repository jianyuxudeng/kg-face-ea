{
  "EN": {
		"t1": "GAME FEATURES",
		"t2": "READ FULL REVIEW",
		"t3": "GUIDE",
		"t4": "ANOUNCEMENTS",
		"t5": "EVENT",
		"t6": "READ MORE",
		"t7": "MORE",
		"t8": "COMMUNITY",
		"t9": "FOLLOW US",
		"menu":[
			"STORY",
			"HEROES",
			"FEATURES",
			"MEDIA REVIEW",
			"GAME INFO",
			"COMMUNITY"
		],
		"subMenu":[
			"ANNOUNCEMENTS",
			"EVENTS",
			"GUIDES"
		]
	},
  "FR": {
		"t1": "Fonctionnalités",
		"t2": "LIRE AVIS COMPLET",
		"t3": "Infos du jeu",
		"t4": "Annonces",
		"t5": "Événements",
		"t6": "LIRE PLUS",
		"t7": "PLUS",
		"t8": "Communauté",
		"t9": "SUIVEZ-NOUS",
		"menu":[
			"Histoire",
			"Héros",
			"Fonctionnalités",
			"Communiqué de presse",
			"Infos du jeu",
			"Communauté"
		],
		"subMenu":[
			"Annonces",
			"Événement",
			"Guide"
		]
		
	},
  "DE": {
		"t1": "Features",
		"t2": "GANZEN BERICHT LESEN",
		"t3": "Gameplay-Leitfäden",
		"t4": "Ankündigungen",
		"t5": "Events",
		"t6": "WEITERLESEN",
		"t7": "WEITER",
		"t8": "Community",
		"t9": "FOLGE UNS",
		"menu":[
			"Story",
			"Helden",
			"Features",
			"BEWERTUNG IN DEN MEDIEN",
			"Spielinfo",
			"Community"
		],
		"subMenu":[
			"Ankündigungen",
			"Event",
			"Leitfaden"
		]
	},
  "RU": {
		"t1": "Функции",
		"t2": "ЧИТАТЬ ПОЛНЫЙ ОТЗЫВ",
		"t3": "Руководства по игре",
		"t4": "Объявления",
		"t5": "События",
		"t6": "ПОДРОБНЕЕ",
		"t7": "БОЛЬШЕ",
		"t8": "Сообщество",
		"t9": "ПОДПИСАТЬСЯ",
		"menu":[
			"История",
			"Герои",
			"Функции",
			"ОТЗЫВЫ СМИ",
			"Об игре",
			"Сообщество"
		],
		"subMenu":[
			"Объявления",
			"Событие",
			"Справка"
		]
		
	},
  "AR": {
		"t1": "مميزات",
		"t2": "إقرأ المراجعة الكاملة",
		"t3": "دليل اللعبة",
		"t4": "إعلانات",
		"t5": "الأحداث",
		"t6": "إقرأ المزيد",
		"t7": "المزيد",
		"t8": "التواصل الإجتماعي",
		"t9": "تابعنا",
		"menu":[
			"قصة",
			"أبطال",
			"مميزات",
			"استعراض وسائط الإعلام",
			"معلومات اللعبة",
			"التواصل الإجتماعي"
		],
		"subMenu":[
			"إعلانات",
			"حدث",
			"دليل"
		]
	}
}
